import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allmodules',
  templateUrl: './allmodules.component.html',
  styleUrls: ['./allmodules.component.css']
})
export class AllmodulesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
